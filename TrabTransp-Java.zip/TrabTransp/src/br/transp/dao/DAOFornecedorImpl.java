package br.transp.dao;

public class DAOFornecedorImpl {

}
